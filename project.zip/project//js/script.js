document.getElementById("loginform").addEventListener('submit',function(event) {event.preventDefault(); // mencegah form untuk submit secara deafult
            
            // mendapatkan nilai username dan password
            var username = document.getElementById('username').value;
            var username = document.getElementById('password').value;
            var errormessage = document.getElementById('error-message');
            
            // validasi username dan password
            if (username === '' || password === ''){
                errormessage.textContent = 'gaboleh kosong jawa !!';
                
            } else if (username !== 'panji'|| password !=='123') {
                    errormessage.textContent = 'username atau password salah';
                } else {
                    errormessage.textContent = ''
                    alert('sukses login!!');
                }
                
            } ) ;